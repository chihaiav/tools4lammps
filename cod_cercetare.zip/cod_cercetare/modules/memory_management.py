from config.global_setting import OTHER_DEFAULTS


class Memory_handler:
    @staticmethod
    def free_atom_memory():
        pass

        print("Memory deallocated - erased")